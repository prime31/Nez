<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="[Base]BaseChip_pipo" tilewidth="32" tileheight="32" tilecount="1064" columns="8">
 <image source="[Base]BaseChip_pipo.png" width="256" height="4256"/>
</tileset>
