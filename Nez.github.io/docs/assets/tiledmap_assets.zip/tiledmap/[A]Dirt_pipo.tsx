<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="[A]Dirt_pipo" tilewidth="32" tileheight="32" tilecount="336" columns="8">
 <image source="[A]Dirt_pipo.png" width="256" height="1344"/>
</tileset>
